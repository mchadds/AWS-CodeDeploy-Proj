rm /var/www/html/index.html
cp /revision/index.html /var/www/html/index.html